﻿using HospitalDAL;
using HospitalManangementSystem;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace HospitalManangementSystem
{
    public class DeletionHistoryRecord
    {
        public int PatientId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Disease { get; set; }
        public DateTime DeletionDate { get; set; }
        public string Timestamp { get; set; } // New property for additional metadata
    }

    public class DeletionHistoryManager
    {
        private string patientHistoryFilePath = "DeletedPatients.json";  // New file for deleted patients
        private string doctorHistoryFilePath = "DeletedDoctors.json";    // New file for deleted doctors
        private string appointmentHistoryFilePath = "DeletedAppointments.json"; // New file for deleted appointments

        public void SavePatientDeletionRecord(Patient patient)
        {
            SaveDeletionRecord(patient, patientHistoryFilePath);
        }

        public void SaveDoctorDeletionRecord(Doctor doctor)
        {
            SaveDeletionRecord(doctor, doctorHistoryFilePath);
        }

        public void SaveAppointmentDeletionRecord(Appointment appointment)
        {
            SaveDeletionRecord(appointment, appointmentHistoryFilePath);
        }

        private void SaveDeletionRecord<T>(T record, string filePath)
        {
            try
            {
                // Create a history record
                var deletionRecord = new DeletionHistoryRecord
                {
                    // Populate based on type
                    PatientId = record is Patient p ? p.PatientId : (record is Doctor d ? d.DoctorId : 0),
                    Name = record is Patient pp ? pp.Name : (record is Doctor dd ? dd.DoctorName : string.Empty),
                    Email = record is Patient pp1 ? pp1.Email : string.Empty,
                    Disease = record is Patient pp2 ? pp2.Disease : string.Empty,
                    DeletionDate = DateTime.Now,
                    Timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") // Add formatted timestamp
                };

                List<DeletionHistoryRecord> historyRecords = GetHistoryRecords(filePath);
                historyRecords.Add(deletionRecord);
                SaveHistoryToFile(historyRecords, filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while saving deletion record: {ex.Message}");
            }
        }

        private List<DeletionHistoryRecord> GetHistoryRecords(string filePath)
        {
            if (!File.Exists(filePath))
                return new List<DeletionHistoryRecord>();

            string json = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<List<DeletionHistoryRecord>>(json) ?? new List<DeletionHistoryRecord>();
        }

        private void SaveHistoryToFile(List<DeletionHistoryRecord> historyRecords, string filePath)
        {
            string json = JsonSerializer.Serialize(historyRecords);
            File.WriteAllText(filePath, json);
        }

        public void DisplayDeletionHistory(string type)
        {
            string filePath = type switch
            {
                "patient" => patientHistoryFilePath,
                "doctor" => doctorHistoryFilePath,
                "appointment" => appointmentHistoryFilePath,
                _ => throw new ArgumentException("Invalid type specified.")
            };

            try
            {
                if (!File.Exists(filePath))
                {
                    Console.WriteLine($"No {type} deletion history found.");
                    return;
                }

                string json = File.ReadAllText(filePath);
                var historyRecords = JsonSerializer.Deserialize<List<DeletionHistoryRecord>>(json);

                if (historyRecords == null || historyRecords.Count == 0)
                {
                    Console.WriteLine($"No {type} deletion records available.");
                    return;
                }

                Console.WriteLine($"{type} Deletion History:");
                foreach (var record in historyRecords)
                {
                    Console.WriteLine($"ID: {record.PatientId}, Name: {record.Name}, Email: {record.Email}, Disease: {record.Disease}, " +
                                      $"Deleted On: {record.DeletionDate}, Timestamp: {record.Timestamp}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while reading {type} deletion history: {ex.Message}");
            }
        }
    }
}