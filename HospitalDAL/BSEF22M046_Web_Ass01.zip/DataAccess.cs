﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Collections;
using System.Numerics;
using System.IO;
using System.ComponentModel.Design;
using HospitalManangementSystem;
namespace HospitalDAL
{
    public class DataAccess
    {

        //input validation function for email
        public static bool IsValidEmail(string email)
        {
            // Check if the email is null or empty
            if (string.IsNullOrWhiteSpace(email))
            {
               return false;
            }
            bool hasAtSymbol = false;
            bool hasDot = false;

            for (int i = 0; i < email.Length; i++)
            {
                // Check for the '@' symbol
                if (email[i] == '@')
                {
                    if (hasAtSymbol) // Check for multiple '@' symbols
                    {
                        return false;
                    }
                    hasAtSymbol = true;
                }

                if (email[i] == '.')
                {
                    hasDot = true;
                }
            }

            // Ensure both symbols are present
            return hasAtSymbol && hasDot;
        }

        // Insert Functions

        public void InsertPatient(Patient patient)
        {
            Console.Write("Enter Name: ");
            patient.Name = Console.ReadLine();

            Console.Write("Enter Email: ");
            patient.Email = Console.ReadLine();
            if (IsValidEmail(patient.Email))
            {
                Console.Write("Enter Disease: ");
                patient.Disease = Console.ReadLine();

                // Database connection string
                string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

                using (SqlConnection sqlConnection = new SqlConnection(connString))
                {
                    sqlConnection.Open();

                    // Parameterized SQL query
                    string query = "INSERT INTO Patient(name, email, disease) VALUES (@Name, @Email, @Disease)";

                    using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                    {
                        // Add parameters with their respective values
                        cmd.Parameters.AddWithValue("@Name", patient.Name);
                        cmd.Parameters.AddWithValue("@Email", patient.Email);
                        cmd.Parameters.AddWithValue("@Disease", patient.Disease);

                        try
                        {
                            cmd.ExecuteNonQuery(); // Execute the command
                            Console.WriteLine("Patient inserted successfully.");
                        }
                        catch (SqlException sqlEx)
                        {
                            Console.WriteLine("An error occurred while inserting the patient: " + sqlEx.Message);
                        }
                    }
                }

            }
            else
            {
                while (!IsValidEmail(patient.Email))
                {
                    patient.Email = Console.ReadLine();
                }
            }
        }
        public void InsertDoctor(Doctor doctor)
        {
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            using (SqlConnection sc = new SqlConnection(connString))
            {
                sc.Open();

                Console.Write("Enter the doctor name: ");
                doctor.DoctorName = Console.ReadLine();

                Console.Write("Enter the doctor specialization: ");
                doctor.DoctorSpecialization = Console.ReadLine();

                // Parameterized SQL query
                string query = "INSERT INTO Doctor(doctorName, doctorSpecialization) VALUES(@doctorName, @doctorSpecialization)";

                using (SqlCommand cmd = new SqlCommand(query, sc))
                {
                    // Add parameters with their respective values
                    cmd.Parameters.AddWithValue("@doctorName", doctor.DoctorName);
                    cmd.Parameters.AddWithValue("@doctorSpecialization", doctor.DoctorSpecialization);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Doctor added successfully.");
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("Some error occurred: " + sqlEx.Message);
                    }
                } // No need for finally to close connection,it is already handled by using statement
            }
        }

        public void InsertAppointment(Appointment a)
        {
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sc = new SqlConnection(connString))
            {
                sc.Open();

                Console.Write("Enter the patient Id: ");
                a.PatientId = int.Parse(Console.ReadLine());

                Console.Write("Enter the doctor Id: ");
                a.DoctorId = int.Parse(Console.ReadLine());

                Console.Write("Enter the appointment date (yyyy-MM-dd): ");
                a.AppointmentDate = DateTime.Parse(Console.ReadLine());

                // Parameterized SQL query
                string query = "INSERT INTO Appointment(patientId, doctorId, appointmentDate) VALUES(@patientId, @doctorId, @appointmentDate)";

                using (SqlCommand cmd = new SqlCommand(query, sc))
                {
                    // Add parameters with their respective values
                    cmd.Parameters.AddWithValue("@patientId", a.PatientId);
                    cmd.Parameters.AddWithValue("@doctorId", a.DoctorId);
                    cmd.Parameters.AddWithValue("@appointmentDate", a.AppointmentDate);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Appointment added successfully.");
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("Some error occurred: " + sqlEx.Message);
                    }
                } // No need for finally to close connection, handled by using statement
            }
        }



        public void DeletePatientFromDatabase(int patientId)
        {
            //History h = new History();
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();

                string query = "DELETE FROM patient WHERE patientId = @PatientId";
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.Parameters.AddWithValue("@PatientId", patientId);

                    try
                    {
                        int count = sqlCommand.ExecuteNonQuery(); // Execute the command

                        if (count > 0)
                        {
                            Console.WriteLine("Patient deleted successfully.");
                        }
                        else
                        {
                            Console.WriteLine("No patient found with the given ID.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while deleting the patient: " + sqlEx.Message);
                    }
                }
            }
        }
        public void DeleteDoctorFromDatabase(int docId)
        {
            //History h = new History();
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();

                string query = "DELETE FROM Doctor WHERE doctorId = @docId";
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.Parameters.AddWithValue("@DoctorId", docId);

                    try
                    {
                        int count = sqlCommand.ExecuteNonQuery(); // Execute the command

                        if (count > 0)
                        {
                            Console.WriteLine("Doctor deleted successfully.");
                        }
                        else
                        {
                            Console.WriteLine("No doctor found with the given ID.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while deleting the doctor: " + sqlEx.Message);
                    }
                }
            }
        }

        public void DeleteAppointmentFromDatabase(int appId)
        {
            //History h = new History();
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();

                string query = "DELETE FROM Assignment WHERE assignmentId = @assId";
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.Parameters.AddWithValue("@AppointmentId", appId);

                    try
                    {
                        int count = sqlCommand.ExecuteNonQuery();

                        if (count > 0)
                        {
                            Console.WriteLine("Appointment deleted successfully.");
                        }
                        else
                        {
                            Console.WriteLine("No appointment found with the given ID.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while deleting the appointment: " + sqlEx.Message);
                    }
                }
            }
        }

        public void UpdatePatientInDatabase(Patient patient)
        {
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();

                string query = "UPDATE patient SET name = @Name, email = @Email, disease = @Disease WHERE patientId = @PatientId";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    Console.Write("Enter patient Id that needs to be updated");
                    string patientId = Console.ReadLine();
                    Console.Write("Enter updated name");
                    string newName = Console.ReadLine();
                    Console.Write("Enter updated email");
                    string newEmail = Console.ReadLine();
                    Console.Write("Enter updated disease");
                    string newDisease = Console.ReadLine();
                    sqlCommand.Parameters.AddWithValue("@Name", newName);
                    sqlCommand.Parameters.AddWithValue("@Email", newEmail);
                    sqlCommand.Parameters.AddWithValue("@Disease", newDisease);
                    sqlCommand.Parameters.AddWithValue("@PatientId", patientId);

                    try
                    {
                        int rowsAffected = sqlCommand.ExecuteNonQuery(); // Execute the command

                        if (rowsAffected > 0)
                        {
                            Console.WriteLine("Patient updated successfully.");
                        }
                        else
                        {
                            Console.WriteLine("No patient found with the given ID.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while updating the patient: " + sqlEx.Message);
                    }
                }
            }
        }

        public void UpdateDoctorInDatabase(Doctor d)
        {
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();
                string query = "UPDATE doctor SET doctorName = @DoctorName, doctorSpecialization = @DoctorSpecialization WHERE doctorId = @DoctorId";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    Console.Write("Enter doctor Id that needs to be updated: ");
                    string doctorId = Console.ReadLine();
                    Console.Write("Enter updated doctor name: ");
                    string newName = Console.ReadLine();
                    Console.Write("Enter updated specialization: ");
                    string newSpec = Console.ReadLine();

                    // Assign parameters
                    sqlCommand.Parameters.AddWithValue("@DoctorName", newName);
                    sqlCommand.Parameters.AddWithValue("@DoctorSpecialization", newSpec);

                    try
                    {
                        int rowsAffected = sqlCommand.ExecuteNonQuery(); // Execute the command

                        if (rowsAffected > 0)
                        {
                            Console.WriteLine("Doctor updated successfully.");
                        }
                        else
                        {
                            Console.WriteLine("No doctor found with the given ID.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while updating the doctor: " + sqlEx.Message);
                    }
                }
            }

        }

        public void UpdateAppointmentInDatabase(Appointment a)
        {
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();
                string query = "UPDATE Appointment SET appointmentDate = @a.AppointmentDate";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {

                    Console.Write("Enter updated appointment date: ");
                    string newDate = Console.ReadLine();

                    // Assign parameters
                    sqlCommand.Parameters.AddWithValue("@DoctorSpecialization", newDate);

                    try
                    {
                        int rowsAffected = sqlCommand.ExecuteNonQuery(); // Execute the command

                        if (rowsAffected > 0)
                        {
                            Console.WriteLine("Appointment updated successfully.");
                        }
                        else
                        {
                            Console.WriteLine("No appointment exists");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while updating the appointment: " + sqlEx.Message);
                    }
                }
            }

        }

        public List<Patient> SearchPatientsInDatabase(string name)
        {
            List<Patient> patients = new List<Patient>();
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();

                string query = "SELECT patientId, name, email, disease FROM patient WHERE name LIKE @Name";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.Parameters.AddWithValue("@Name", "%" + name + "%");

                    try
                    {
                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            while (reader.Read()) // Read all matching records
                            {
                                // Create a Patient object and populate it with values from the database
                                Patient patient = new Patient
                                {
                                    PatientId = reader.GetInt32(0), // patientId
                                    Name = reader.GetString(1),      // name
                                    Email = reader.GetString(2),     // email
                                    Disease = reader.GetString(3)     // disease
                                };
                                patients.Add(patient); // Add to the list
                            }
                        }

                        if (patients.Count > 0)
                        {
                            Console.WriteLine($"{patients.Count} patient(s) found with the name '{name}'.");
                        }
                        else
                        {
                            Console.WriteLine("No patients found with the given name.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while searching for patients: " + sqlEx.Message);
                    }
                }
            }

            return patients;
        }

        public List<Doctor> SearchDoctorsInDatabase(string docName)
        {
            List<Doctor> doctors = new List<Doctor>();
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();

                // Corrected query to search doctors, not patients
                string query = "SELECT doctorId, doctorName, doctorSpecialization FROM Doctor WHERE doctorName LIKE @Name";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.Parameters.AddWithValue("@Name", "%" + docName + "%");

                    try
                    {
                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            while (reader.Read()) // Read all matching records
                            {
                                // Create a Doctor object and populate it with values from the database
                                Doctor d = new Doctor
                                {
                                    DoctorId = reader.GetInt32(0),               // doctorId
                                    DoctorName = reader.GetString(1),            // doctorName
                                    DoctorSpecialization = reader.GetString(2)   // doctorSpecialization
                                };
                                doctors.Add(d); // Add to the list
                            }
                        }

                        if (doctors.Count > 0)
                        {
                            Console.WriteLine($"{doctors.Count} doctor(s) found with the name '{docName}'.");
                        }
                        else
                        {
                            Console.WriteLine("No doctors found with the given name.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while searching for doctors: " + sqlEx.Message);
                    }
                }
            }

            return doctors;
        }


        public List<Appointment> SearchAppointmentsInDatabase(int patientId, int doctorId)
        {
            List<Appointment> appointments = new List<Appointment>();
            string connString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(connString))
            {
                sqlConnection.Open();

                // Direct query with patientId and doctorId
                string query = "SELECT appointmentId, patientId, doctorId, appointmentDate FROM Appointment WHERE patientId = @PatientId AND doctorId = @DoctorId";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    // Add parameters to the command
                    sqlCommand.Parameters.AddWithValue("@PatientId", patientId);
                    sqlCommand.Parameters.AddWithValue("@DoctorId", doctorId);

                    try
                    {
                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            while (reader.Read()) // Read all matching records
                            {
                                // Create an Appointment object and populate it with values from the database
                                Appointment appointment = new Appointment
                                {
                                    AppointmentId = reader.GetInt32(0),       // appointmentId
                                    PatientId = reader.GetInt32(1),          // patientId
                                    DoctorId = reader.GetInt32(2),            // doctorId
                                    AppointmentDate = reader.GetDateTime(3)   // appointmentDate
                                };
                                appointments.Add(appointment); // Add to the list
                            }
                        }

                        if (appointments.Count > 0)
                        {
                            Console.WriteLine($"{appointments.Count} appointment(s) found.");
                        }
                        else
                        {
                            Console.WriteLine("No appointments found with the given patient and doctor IDs.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while searching for appointments: " + sqlEx.Message);
                    }
                }
            }

            return appointments;
        }

        public List<Patient> GetAllPatientsFromDatabase()
        {
            List<Patient> patients = new List<Patient>();

            string conn = @"Data Source=(localdb)\ProjectModels;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            using (SqlConnection sqlConnection = new SqlConnection(conn))
            {
                sqlConnection.Open();

                // SQL query to select all patients
                string query = "SELECT patientId, name, email, disease FROM patient";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    try
                    {
                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            while (reader.Read()) // Loop through the results
                            {
                                Patient patient = new Patient
                                {
                                    PatientId = reader.GetInt32(0), 
                                    Name = reader.GetString(1),     
                                    Email = reader.GetString(2),     
                                    Disease = reader.IsDBNull(3) ? null : reader.GetString(3) // disease with handling for nulls
                                };
                                patients.Add(patient); // Add to the list
                            }
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        Console.WriteLine("An error occurred while retrieving patients: " + sqlEx.Message);
                    }
                }
            }

            return patients; // Return the list of patients
        }
    }
}

